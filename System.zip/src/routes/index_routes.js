const {Router} =require('express')
const router = Router();
const {renderIndex,renderAbout} = require('../controllers/indexController')

module.exports = router;

router.get('/',renderIndex)
router.get('/about',renderAbout)