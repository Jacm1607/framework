const { Schema, model } = require('mongoose')

const InputSchema = new Schema({
    input: {
        type: String,
        required: true
    },
    style: {
        type: String,
        required: true
    }
}, {
    timestamps: true
})

module.exports = model('Input', InputSchema)