/***************************/
//      CONFIG SERVER      //
/***************************/
const express = require('express');
const path = require('path');
const exphbs = require('express-handlebars')

//Initializations
const app = express();

//Settings of port
app.set('port', process.env.PORT || 4000);
app.set('views', path.join(__dirname, 'views'))
app.engine('.hbs', exphbs({
    defaultLayout: 'main',
    layoutsDir: path.join(app.get('views'), 'layouts'),
    partialsDir: path.join(app.get('views'), 'partials'),
    extname: '.hbs'
}));
app.set('view engine','.hbs');

//Middlewares
app.use(express.urlencoded({ extended: false }));
//Global Variables

//Routes
app.use(require('./routes/index_routes'))
//Static Files
app.use(express.static(path.join(__dirname, 'public')))

module.exports = app;

